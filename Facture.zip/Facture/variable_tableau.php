<?php 

$mail = "mielle.cosmetics@hotmail.fr";


$client = array(
    array(
        "nom"=>"Jacquet",
        "prenom"=>"Marie",
        "adresse"=>"45 avenue du chêne<br>92240 - Malakoff")
    
    );
    

$numero = mt_rand(1,100000);

$date = date("d/m/Y");

$quantité = mt_rand(1,10);

$entete = array("Références","Nom","Prix unitaire (€)","Quantité","Total");

$produit = array(
    array(
        "reference"=>"1",
        "nom"=>"Shampoing revitalisant",
        "prix"=> 8.99 ,
        "quantite"=> mt_rand(1,10),
       
        ),
    
    array(
        "reference"=>"2",
        "nom"=>"Après-Shampoing réparateur",
        "prix"=> 13.99 ,
        "quantite"=> mt_rand(1,10),
        
        ),
        

    array(
        "reference"=>"3",
        "nom"=>"Masque hydratant",
        "prix"=> 14.99 ,
        "quantite"=> mt_rand(1,10),
        
        ),
        

    array(
        "reference"=>"4",
        "nom"=>"Leave-in",
        "prix"=> 6.99 ,
        "quantite"=> mt_rand(1,10),
        
        ),
        

    array(
        "reference"=>"5",
        "nom"=>"Gel boucles",
        "prix"=> 6.99 ,
        "quantite"=> mt_rand(1,10),
        
        ),
       

 );




function totaux($prix,$quantité)
{
    $total = $prix * $quantité;

    return($total);
    
}


    
    foreach($produit as $prod)
{
    $total = 0;
    $total += $prod["prix"]*$prod["quantite"];
}

function calcul_ttc($ht,$tva=20)
{
    $ttc = $ht + ($ht * $tva / 100); 
     
    return($ttc);
}

function calcul_pourcentage($total,$tva=20)
{
    $pourcent = ($total * $tva / 100);

    return($pourcent);
}

?>