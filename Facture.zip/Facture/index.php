<?php

include("variable_tableau.php")

?>


<!DOCTYPE html>
<html style = "background-color: grey" >
    <head>
        <title>Ma facture</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>

    <body>
        <header>
            
            <form>
                <input type="button" value="Imprimer" onClick="window.print()">
            </form>


            <figure>
                <img src="miel.png" alt="Mon logo">
            </figure>

            


            <div class="entreprise">
                <p> Mielle Cosmetics<br>10 rue petit<br>91260 - Juvisy sur orge<br><a href='mailto:<?php echo($mail); ?>'><?php echo($mail); ?></a></p>
            </div>

            <div class="client">
            <?php
                   for ($i = 0; $i < count($client); $i++)
                   {
                       echo("<p>".$client[$i]["nom"]." ".$client[$i]["prenom"]."<br>
                            ".$client[$i]["adresse"]."</p>");
            
                   }
            ?>
            </div>

        </header>

        <main>
            <h1>Facture n°<?php echo($numero); ?></h1>

            <p class="date"> Date : <?php echo($date); ?></p>

            <section>
                <table class="tableau" border="1" align="center" width="80%" cellspacing="0" cellpadding="10">
                
                <tr>
                <th><?php echo($entete[0]); ?></th>
                <th><?php echo($entete[1]); ?></th>
                <th><?php echo($entete[2]); ?></th>
                <th><?php echo($entete[3]); ?></th>
                <th><?php echo($entete[4]); ?></th>
                </tr>

<?php
        for ($i = 0; $i < count($produit); $i++)
        {
        echo("<tr>
            <td>".$produit[$i]["reference"]."</td>
            <td>".$produit[$i]["nom"]."</td>
            <td>".$produit[$i]["prix"]."</td>
            <td>".$produit[$i]["quantite"]."</td>
            <td>".$produit[$i]["prix"]*$produit[$i]["quantite"]."</td>
            </tr>"
        );

        }
?>

                </table>
            </section>

            <section class="totaux">

                <table class="totaux" border="1" align="right">
                        <tr>
                        <td><strong>Total Hors Taxes (THT) :</strong></td>
                        <td></strong> <?php echo($total); ?></td>
                        </tr>
                        
                        <tr>
                        <td><strong>TVA (20%) :</strong></td>
                        <td><?php echo(calcul_pourcentage($total)); ?></td>
                        </tr>
                        
                        <tr>
                        <td><strong>Total Tout Compris (TTC) :</strong></td>
                        <td><?php echo(calcul_ttc($total)); ?></td>
                        </tr>
                        
                </table>
                        
            </section>
           





        </main>

        <footer>
            <section class="bas_de_page">
                <div class="mentions">

                    <p><strong>Mentions légales :</strong><br> 

                    <p>La facture est payable sous 30 jours dès réception.<br>
                    Aucun escompte consenti pour règlement anticipé.<br>
                    Tout incident de paiment est passible de frais de retard.<br> 
                    Tout règlement effectué après expiration du délai donneras<br>
                    lieu, à titre de pénalité de retard, à l'application d'un<br> 
                    intérêt égal à celui appliqué par la Banque Centrale<br>
                    Européenne à son opération de refinancement la plus récente,<br>
                    majoré de 10 points de pourcentage, ainsi qu'a une indemnité<br>
                    forfaitaire pour frais de recouvrement<br>
                    d'un montant de 40 Euros.<br>
                    Les pénalités de retard son exigibles sans qu'un appel soit nécessiare.</p>
                </div>

                <div class="banque">
                    <p><strong>Coordonnées bancaire :</strong><br>
                    IBAN : 6765 5536 8567 5467 6548 654<br> 
                    BIC : HGJGF67</p>
                </div>

            </section>
        </footer>

    </body>

</html>

